export interface FailureFunction {
  id: string;
  file: string;
  name: string;
  line: number;
  server: boolean;
  component: boolean;
  fails: string[];
  calls: string[];
  rejection?: string[];
}
export interface FailureReport {
  iterations: number;
  diagnostics: { file: string; code: string; message: string; line: number; column: number }[];
  unknownOrigins: {
    file: string;
    start: number;
    end: number;
    line: number;
    name: string;
    owner?: string;
  }[];
  classes: {
    id: string;
    name: string;
    file: string | null;
    nameStart?: number;
    classStart?: number;
  }[];
  functions: FailureFunction[];
  call(
    file: string,
    start: number,
    end: number
  ): { fails: string[]; native: boolean; target?: string; promise: boolean; async: boolean } | null;
  at(
    file: string,
    start: number
  ): { fails: Set<string>; server: boolean; component: boolean } | undefined;
  throws(file: string, start: number, end: number): string[];
}
export function inferFailures(
  modules: Map<string, string>,
  options: { program: import("typescript").Program; ts: typeof import("typescript"); root?: string }
): FailureReport;
